import { Component } from 'react';
import Header from './Header';
import Section from './Section';
import Article from './Article';
import Footer from './Footer';

class App extends Component {
  //state값 생성 
  // Header에 전달할 데이터의 이름 : title(문자열)
  // Footer에 전달할 데이터의 이름 : desc(문자열로된 배열)
  render() {
    return (
      <div>
        {/* title = {this.state.title} */}
        <Header />
        <hr />
        <Section />
        <Article />
        {/* desc = {this.state.desc} */}
        <Footer />
      </div>
    );
  }
}

export default App;
