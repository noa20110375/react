import { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <header>
        <h1>야구게임 방식</h1>
      </header>
    );
  }
}

export default Header;