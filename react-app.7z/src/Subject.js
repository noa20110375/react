import { Component } from 'react';

class Subject extends Component {
  render() {
    // this.props.title = "제목 수정 테스트"; -> props에 있는 데이터는 수정이 안됨.
    return (
      <header>
        {/* 
          컴포넌트 내부에서 전달받은 데이터 사용시 - props : 
          this.props 내부에 있는 데이터의 이름을 활용
        */}
        <h1>{this.props.title}</h1>
        {this.props.sub}
      </header>
    );
  }
}

export default Subject;